import { useEffect, useRef, useState } from 'react';

const AboutSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} id="about" className="py-20 bg-background relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          
          {/* Section Title */}
          <div className={`text-center mb-16 reveal ${isVisible ? 'revealed' : ''}`}>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-foreground to-accent bg-clip-text text-transparent">
              Tentang Saya
            </h2>
            <div className="w-20 h-1 bg-gradient-accent mx-auto rounded-full" />
          </div>

          {/* Content Grid */}
          <div className="grid md:grid-cols-2 gap-12 items-center">
            
            {/* Text Content */}
            <div className={`space-y-6 reveal ${isVisible ? 'revealed' : ''} transition-delay-200`}>
              <div className="prose prose-lg text-muted-foreground">
                <p className="text-lg leading-relaxed">
                  Saya adalah seorang developer yang memiliki keahlian dalam pengembangan bot WhatsApp untuk memberikan pengalaman interaktif yang efisien bagi pengguna.
                </p>
                
                <p className="text-lg leading-relaxed">
                  Selain itu, saya juga berpengalaman dalam pengembangan aplikasi, baik itu aplikasi web, mobile, maupun desktop. Dengan pengetahuan mendalam tentang berbagai bahasa pemrograman dan teknologi terbaru.
                </p>
                
                <p className="text-lg leading-relaxed">
                  saya berfokus pada pembuatan solusi yang mudah digunakan dan dapat meningkatkan produktivitas serta komunikasi bagi penggunanya.
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-8">
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent">50+</div>
                  <div className="text-sm text-muted-foreground">Proyek Selesai</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent">3+</div>
                  <div className="text-sm text-muted-foreground">Tahun Pengalaman</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-accent">100%</div>
                  <div className="text-sm text-muted-foreground">Kepuasan Klien</div>
                </div>
              </div>
            </div>

            {/* Visual Element */}
            <div className={`reveal ${isVisible ? 'revealed' : ''} transition-delay-400`}>
              <div className="relative">
                <div className="bg-gradient-card rounded-3xl p-8 shadow-card border border-border/50">
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-foreground mb-6">Filosofi Kerja</h3>
                    
                    <div className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-accent rounded-full mt-3 flex-shrink-0" />
                        <p className="text-muted-foreground">Fokus pada kualitas dan performa optimal</p>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-accent rounded-full mt-3 flex-shrink-0" />
                        <p className="text-muted-foreground">Komunikasi yang jelas dan transparan</p>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-accent rounded-full mt-3 flex-shrink-0" />
                        <p className="text-muted-foreground">Pembelajaran berkelanjutan dan adaptasi</p>
                      </div>
                      
                      <div className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-accent rounded-full mt-3 flex-shrink-0" />
                        <p className="text-muted-foreground">Kolaborasi tim yang efektif</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Decorative Elements */}
                <div className="absolute -top-4 -right-4 w-8 h-8 bg-accent/20 rounded-full animate-pulse" />
                <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-primary-glow/20 rounded-full animate-pulse delay-1000" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;