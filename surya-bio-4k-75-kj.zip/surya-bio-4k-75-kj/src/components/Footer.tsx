const Footer = () => {
  return (
    <footer className="bg-card/50 border-t border-border/50 py-12 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          
          {/* Main Content */}
          <div className="mb-8">
            <div className="w-16 h-1 bg-gradient-accent mx-auto rounded-full mb-6" />
            
            <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-foreground to-accent bg-clip-text text-transparent">
              Mari Wujudkan Ide Digital Anda
            </h3>
            
            <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Siap untuk memulai proyek berikutnya? Saya siap membantu mewujudkan visi digital Anda 
              dengan teknologi terdepan dan desain yang menawan.
            </p>
          </div>

          {/* Divider */}
          <div className="w-full h-px bg-gradient-to-r from-transparent via-border to-transparent my-8" />

          {/* Footer Info */}
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-muted-foreground">
              <p>&copy; 2025 Profile Website. Designed dengan  menggunakan React & TypeScript</p>
            </div>
            
            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <button 
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="hover:text-accent transition-colors duration-300 hover:scale-105 transform"
              >
                Back to Top ↑
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Background Animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-accent/5 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-primary-glow/5 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>
    </footer>
  );
};

export default Footer;