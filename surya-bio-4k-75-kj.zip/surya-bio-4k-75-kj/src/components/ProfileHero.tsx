import { useEffect, useState } from 'react';
import { useTypewriter } from '../hooks/useTypewriter';
import profilePhoto from '../assets/profile-photo.jpg';

const ProfileHero = () => {
  const [isVisible, setIsVisible] = useState(false);
  const { displayText, isComplete } = useTypewriter({ 
    text: "Halo, Saya surya4k saya berumur 17 salam kenal", 
    speed: 100, 
    delay: 1000 
  });

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-hero overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-transparent to-background/80" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          
          {/* Profile Image */}
          <div className={`mb-8 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-8 scale-95'
          }`}>
            <div className="relative inline-block">
              <div className="w-48 h-48 mx-auto rounded-full overflow-hidden border-4 border-accent/30 shadow-glow">
                <img 
                  src={profilePhoto} 
                  alt="Profile Photo" 
                  className="w-full h-full object-cover animate-scale-in"
                />
              </div>
              <div className="absolute inset-0 rounded-full bg-gradient-accent opacity-20 animate-pulse" />
            </div>
          </div>

          {/* Main Heading */}
          <div className={`space-y-6 transition-all duration-1000 delay-300 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}>
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-foreground via-accent to-accent-soft bg-clip-text text-transparent">
              {displayText}
              <span className={`inline-block w-1 h-16 bg-accent ml-2 animate-pulse ${isComplete ? 'opacity-0' : 'opacity-100'}`}>|</span>
            </h1>
            
            <div className="w-24 h-1 bg-gradient-accent mx-auto rounded-full" />
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Passionate full-stack developer yang berfokus pada menciptakan pengalaman digital yang luar biasa 
              dengan teknologi modern dan desain yang elegan.
            </p>
          </div>

          {/* CTA Button */}
          <div className={`mt-12 transition-all duration-1000 delay-600 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}>
            <button 
              onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
              className="group relative px-8 py-4 bg-gradient-accent text-accent-foreground font-semibold rounded-full 
                         hover:shadow-hover transition-all duration-300 hover:scale-105"
            >
              <span className="relative z-10">Pelajari Lebih Lanjut</span>
              <div className="absolute inset-0 bg-white/10 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </button>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-accent/10 rounded-full animate-pulse" />
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-primary-glow/10 rounded-full animate-pulse delay-1000" />
    </section>
  );
};

export default ProfileHero;