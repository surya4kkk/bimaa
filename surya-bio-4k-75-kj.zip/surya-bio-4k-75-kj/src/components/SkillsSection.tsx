import { useEffect, useRef, useState } from 'react';
import { Code2, Server, Palette, Layers } from 'lucide-react';

interface Skill {
  name: string;
  icon: React.ElementType;
  description: string;
  color: string;
}

const skills: Skill[] = [
  {
    name: "HTML",
    icon: Code2,
    description: "Semantic markup dan struktur web modern",
    color: "from-orange-500 to-red-500"
  },
  {
    name: "Node.js",
    icon: Server,
    description: "Backend development dan API creation",
    color: "from-green-500 to-emerald-600"
  },
  {
    name: "TypeScript",
    icon: Layers,
    description: "Type-safe JavaScript development",
    color: "from-blue-500 to-indigo-600"
  },
  {
    name: "UI/UX Design",
    icon: Palette,
    description: "User-centered design dan prototyping",
    color: "from-purple-500 to-pink-500"
  }
];

const SkillsSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [progressValues, setProgressValues] = useState<number[]>([0, 0, 0, 0]);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Animate progress values when visible
  useEffect(() => {
    if (isVisible) {
      const targetValues = [95, 88, 92, 90]; // Different expertise levels for each skill
      const animationDuration = 2000; // 2 seconds
      const steps = 50;
      const stepDuration = animationDuration / steps;

      skills.forEach((_, index) => {
        let currentStep = 0;
        const interval = setInterval(() => {
          currentStep++;
          const progress = Math.min((currentStep / steps) * targetValues[index], targetValues[index]);
          
          setProgressValues(prev => {
            const newValues = [...prev];
            newValues[index] = Math.round(progress);
            return newValues;
          });

          if (currentStep >= steps) {
            clearInterval(interval);
          }
        }, stepDuration + (index * 100)); // Stagger each skill animation
      });
    }
  }, [isVisible]);

  return (
    <section ref={sectionRef} id="skills" className="py-20 bg-card/30 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          
          {/* Section Title */}
          <div className={`text-center mb-16 reveal ${isVisible ? 'revealed' : ''}`}>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-foreground to-accent bg-clip-text text-transparent">
              My Skills
            </h2>
            <div className="w-20 h-1 bg-gradient-accent mx-auto rounded-full" />
            <p className="text-xl text-muted-foreground mt-6 max-w-2xl mx-auto">
              Teknologi dan tools yang saya gunakan untuk menciptakan pengalaman digital yang luar biasa
            </p>
          </div>

          {/* Skills Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {skills.map((skill, index) => (
              <div
                key={skill.name}
                className={`skill-card p-8 text-center group reveal ${isVisible ? 'revealed' : ''}`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <div className="relative mb-6">
                  {/* Icon Container */}
                  <div className="relative inline-block">
                    <div className={`w-20 h-20 rounded-2xl bg-gradient-to-r ${skill.color} p-4 mx-auto 
                                  transform transition-all duration-500 group-hover:scale-110 group-hover:rotate-6`}>
                      <skill.icon className="w-full h-full text-white" />
                    </div>
                    
                    {/* Glow Effect */}
                    <div className={`absolute inset-0 w-20 h-20 rounded-2xl bg-gradient-to-r ${skill.color} 
                                   opacity-0 group-hover:opacity-30 blur-xl transition-all duration-500 mx-auto`} />
                  </div>
                </div>

                {/* Skill Name */}
                <h3 className="text-xl font-bold mb-3 text-foreground group-hover:text-accent transition-colors duration-300">
                  {skill.name}
                </h3>

                {/* Description */}
                <p className="text-muted-foreground text-sm leading-relaxed group-hover:text-foreground transition-colors duration-300">
                  {skill.description}
                </p>

                {/* Progress Indicator */}
                <div className="mt-6">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs text-muted-foreground">Expertise Level</span>
                    <span className="text-sm font-bold text-accent">{progressValues[index]}%</span>
                  </div>
                  <div className="w-full bg-border/50 rounded-full h-3 overflow-hidden">
                    <div 
                      className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out`}
                      style={{ width: `${progressValues[index]}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Additional Info */}
          <div className={`text-center mt-16 reveal ${isVisible ? 'revealed' : ''} transition-delay-600`}>
            <div className="bg-gradient-card rounded-3xl p-8 border border-border/50 shadow-card max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold mb-4 text-foreground">Selalu Belajar & Berkembang</h3>
              <p className="text-muted-foreground leading-relaxed">
                Teknologi terus berkembang, dan saya berkomitmen untuk terus belajar dan mengasah kemampuan. 
                Saat ini saya sedang memperdalam React, Next.js, dan exploring teknologi AI/ML untuk web development.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Background Decorations */}
      <div className="absolute top-10 right-10 w-32 h-32 bg-accent/5 rounded-full blur-3xl" />
      <div className="absolute bottom-10 left-10 w-40 h-40 bg-primary-glow/5 rounded-full blur-3xl" />
    </section>
  );
};

export default SkillsSection;