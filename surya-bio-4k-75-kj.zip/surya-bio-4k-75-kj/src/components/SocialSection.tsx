import { useEffect, useRef, useState } from 'react';
import { Instagram, Music } from 'lucide-react';

interface SocialPlatform {
  name: string;
  icon: React.ElementType;
  url: string;
  color: string;
  description: string;
}

const socialPlatforms: SocialPlatform[] = [
  {
    name: "Instagram",
    icon: Instagram,
    url: "https://www.instagram.com/xyurazz6", // Replace with actual Instagram URL
    color: "from-pink-500 via-red-500 to-yellow-500",
    description: "Jangan lupa untuk follow akun Instagram saya di untuk mendapatkan update terbaru"
  },
  {
    name: "TikTok", 
    icon: Music,
    url: "tiktok.com/@louzy677", // Replace with actual TikTok URL
    color: "from-black via-red-600 to-white",
    description: "Quick coding tips and tech trends"
  }
];

const SocialSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} id="social" className="py-20 bg-background relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          
          {/* Section Title */}
          <div className={`mb-16 reveal ${isVisible ? 'revealed' : ''}`}>
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-foreground to-accent bg-clip-text text-transparent">
              Mari Terhubung
            </h2>
            <div className="w-20 h-1 bg-gradient-accent mx-auto rounded-full" />
            <p className="text-xl text-muted-foreground mt-6 max-w-2xl mx-auto">
              Follow media sosial saya untuk konten menarik seputar teknologi, programming tips, dan project updates
            </p>
          </div>

          {/* Social Media Cards */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {socialPlatforms.map((platform, index) => (
              <div
                key={platform.name}
                className={`reveal ${isVisible ? 'revealed' : ''}`}
                style={{ transitionDelay: `${index * 200}ms` }}
              >
                <a
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group block"
                >
                  <div className="relative bg-gradient-card rounded-3xl p-8 border border-border/50 shadow-card 
                                hover:shadow-hover transition-all duration-500 hover:scale-105 hover:border-accent/30 overflow-hidden">
                    
                    {/* Background Gradient Effect */}
                    <div className={`absolute inset-0 bg-gradient-to-r ${platform.color} opacity-0 
                                   group-hover:opacity-10 transition-opacity duration-500`} />
                    
                    {/* Icon */}
                    <div className="relative mb-6">
                      <div className={`social-btn mx-auto w-20 h-20 bg-gradient-to-r ${platform.color} 
                                     flex items-center justify-center relative overflow-hidden`}>
                        <platform.icon className="w-10 h-10 text-white relative z-10 
                                                group-hover:scale-110 transition-transform duration-300" />
                      </div>
                    </div>

                    {/* Content */}
                    <div className="relative z-10">
                      <h3 className="text-2xl font-bold mb-4 text-foreground group-hover:text-accent 
                                   transition-colors duration-300">
                        {platform.name}
                      </h3>
                      
                      <p className="text-muted-foreground group-hover:text-foreground transition-colors duration-300 leading-relaxed">
                        {platform.description}
                      </p>

                      {/* Call to Action */}
                      <div className="mt-6">
                        <span className="inline-flex items-center px-4 py-2 bg-accent/10 text-accent rounded-full 
                                       group-hover:bg-accent group-hover:text-accent-foreground transition-all duration-300">
                          Follow @username
                        </span>
                      </div>
                    </div>

                    {/* Shine Effect */}
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent 
                                  translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
                  </div>
                </a>
              </div>
            ))}
          </div>

          {/* Contact CTA */}
          <div className={`reveal ${isVisible ? 'revealed' : ''} transition-delay-400`}>
            <div className="bg-gradient-card rounded-3xl p-8 border border-border/50 shadow-card">
              <h3 className="text-2xl font-bold mb-4 text-foreground">
                Tertarik Berkolaborasi?
              </h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Saya selalu terbuka untuk proyek menarik, kolaborasi, atau sekadar diskusi tentang teknologi. 
                Jangan ragu untuk menghubungi saya!
              </p>
              
              {/* Contact Button, now with WhatsApp link */}
              <a 
                href="https://wa.me/6281297169448" 
                target="_blank" 
                className="group px-8 py-4 bg-gradient-accent text-accent-foreground font-semibold rounded-full 
                         hover:shadow-hover transition-all duration-300 hover:scale-105">
                <span className="relative z-10">Hubungi Saya</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-20 w-24 h-24 bg-accent/10 rounded-full animate-pulse" />
      <div className="absolute bottom-20 right-20 w-32 h-32 bg-primary-glow/10 rounded-full animate-pulse delay-1000" />
    </section>
  );
};

export default SocialSection;