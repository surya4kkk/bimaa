import { useEffect, useState } from 'react';

export const useScrollTrigger = () => {
  const [scrollY, setScrollY] = useState(0);
  const [scrollDirection, setScrollDirection] = useState<'up' | 'down'>('down');
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    let lastScrollY = window.scrollY;

    const updateScrollInfo = () => {
      const currentScrollY = window.scrollY;
      const direction = currentScrollY > lastScrollY ? 'down' : 'up';
      const progress = Math.min(currentScrollY / (document.documentElement.scrollHeight - window.innerHeight), 1);
      
      setScrollY(currentScrollY);
      setScrollDirection(direction);
      setScrollProgress(progress);
      lastScrollY = currentScrollY;
    };

    window.addEventListener('scroll', updateScrollInfo, { passive: true });
    return () => window.removeEventListener('scroll', updateScrollInfo);
  }, []);

  return { scrollY, scrollDirection, scrollProgress };
};