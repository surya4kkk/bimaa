import { useEffect, useRef } from 'react';
import { useScrollTrigger } from '../hooks/useScrollTrigger';
import Navigation from "../components/Navigation";
import ProfileHero from "../components/ProfileHero";
import AboutSection from "../components/AboutSection";
import SkillsSection from "../components/SkillsSection";
import SocialSection from "../components/SocialSection";
import Footer from "../components/Footer";

const Index = () => {
  const { scrollY, scrollDirection, scrollProgress } = useScrollTrigger();
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Add floating elements animation based on scroll
    const floatingElements = document.querySelectorAll('.floating-element');
    floatingElements.forEach((element, index) => {
      const speed = 0.5 + (index * 0.2);
      const yPos = -(scrollY * speed);
      (element as HTMLElement).style.transform = `translate3d(0, ${yPos}px, 0)`;
    });

    // Add parallax background effect
    const parallaxBg = document.querySelector('.parallax-bg');
    if (parallaxBg) {
      (parallaxBg as HTMLElement).style.transform = `translate3d(0, ${scrollY * 0.3}px, 0)`;
    }
  }, [scrollY]);

  return (
    <div ref={mainRef} className="min-h-screen bg-background relative overflow-hidden">
      {/* Scroll Progress Indicator */}
      <div 
        className="fixed top-0 left-0 h-1 bg-gradient-accent z-50 transition-all duration-300"
        style={{ width: `${scrollProgress * 100}%` }}
      />
      
      {/* Floating Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="floating-element absolute top-1/4 -left-10 w-64 h-64 bg-accent/5 rounded-full blur-3xl" />
        <div className="floating-element absolute top-1/2 -right-20 w-96 h-96 bg-primary-glow/5 rounded-full blur-3xl" />
        <div className="floating-element absolute bottom-1/4 left-1/3 w-48 h-48 bg-accent-soft/5 rounded-full blur-3xl" />
      </div>

      {/* Crazy scroll direction indicator */}
      <div className={`fixed right-8 top-1/2 z-40 transition-all duration-500 ${
        scrollDirection === 'down' ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-50'
      }`}>
        <div className="w-1 h-16 bg-gradient-to-b from-accent to-primary-glow rounded-full animate-pulse" />
      </div>

      <Navigation />
      <main className={`transition-all duration-700 ${
        scrollY > 100 ? 'transform -translate-y-2' : 'transform translate-y-0'
      }`}>
        <div className="parallax-bg">
          <ProfileHero />
        </div>
        <div className={`transition-all duration-1000 ${
          scrollY > 200 ? 'opacity-100 translate-y-0' : 'opacity-80 translate-y-8'
        }`}>
          <AboutSection />
        </div>
        <div className={`transition-all duration-1000 ${
          scrollY > 600 ? 'opacity-100 scale-100 rotate-0' : 'opacity-50 scale-95 rotate-1'
        }`}>
          <SkillsSection />
        </div>
        <div className={`transition-all duration-1000 ${
          scrollY > 1000 ? 'opacity-100 translate-x-0' : 'opacity-70 translate-x-8'
        }`}>
          <SocialSection />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
